﻿using System;
using System.Collections.Generic;
$if$ ($targetframeworkversion$ >= 3.5)using System.Linq;
$endif$using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace $rootnamespace$
{
    public partial class $safeitemname$ : BasePage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Page.Title = "$itemname$";
            Page.MetaDescription = "";
            base.Subject = "Citizenship; Immigration; Multiculturalism";		
        }
    }
}